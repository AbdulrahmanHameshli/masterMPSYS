# Task 3 Test Kinematics Kuka Robot

## Description

In this example, we will test the absolute homogeneous transformations (HT)
obtained from the DH table. The robot will be simulated using predefined
joint positions and a trajectory. The assessment is to visually verify that
the coordinate frames obtained from the HT models correspond to the
robot model.

### Files

```
.
└── Robot_Kuka_IIWA_7DOFs
    ├── 01_TestKinematics
    │   ├── plotRobot.m (function to plot the robot and the CFs) [follow the TODOs]
    │   ├── readme.md (This readme file)
    │   └── testKinematics.m (main scripts to run the test) [nothing todo here!]
    ├── DrawCFs: Plotting functions [nothing todo here!]
    └── Model
        ├── kukaIIWA7_params.m (function with the Kinematic parameters) [follow the TODOs]
        └── getAbsoluteHT_kukaIIWA7.m (function to compute absolute HT wrt link 0 and wcf) [follow the TODOs]
```

## How2run

After finishing all the tasks marked as **TODO** in the files: **../Model/kukaIIWA7_params.m**, **Model/getAbsoluteHT_kukaIIWA7.m**, and **plotRobot.m**, run the following commands:

1. use the folder 01_TestKinematics as the workspace. In the matlab terminal
   run:

```bash
>> cd /path_to/Robot_Kuka_IIWA_7DOFs/03_TestKinematics
```

2. Run the main script:

```bash
>> testKinematics
```

3. This will open a plot where you will see the robot and the CFs for all the links and the end-effector (ef)

4. Each time you press a mouse button on the plot a new joint position will be commanded. If your Homogeneous Transformations are properly defined you should see the coordinate frames in the right pose with respect to the robot.
