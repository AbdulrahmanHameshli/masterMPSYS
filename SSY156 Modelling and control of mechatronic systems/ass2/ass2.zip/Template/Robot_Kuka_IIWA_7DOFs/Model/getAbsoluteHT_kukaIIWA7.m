function [HT_0, HT_W] = getAbsoluteHT_kukaIIWA7(q,L, T0_W)

% Use the result from Lab. Assignment 1

end