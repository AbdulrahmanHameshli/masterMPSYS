function Jef_0=J_EF_kukaIIWA7(q,L)

% Use the result from Lab. Assignment 1

end