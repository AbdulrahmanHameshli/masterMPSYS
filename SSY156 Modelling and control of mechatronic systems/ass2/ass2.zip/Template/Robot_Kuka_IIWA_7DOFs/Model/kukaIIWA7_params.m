function L=kukaIIWA7_params

% Use the result from Lab. Assignment 1

end