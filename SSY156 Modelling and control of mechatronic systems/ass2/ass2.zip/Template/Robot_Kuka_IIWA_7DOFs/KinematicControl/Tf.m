function T = Tf(phi)
%TF Computes the Transformation T from derivatives euler ZYZ to angular
%velocities
%   phi: Euler angles vector ZYZ [phi, theta, psi] (3x1)

%TODO: Define the T matrix (3x3) as a function of phi and theta
T=[....];
end

